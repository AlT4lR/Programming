class Bird {
    constructor(name, species, size, habitat, number) {
        this.name = name;
        this.species = species;
        this.habitat = habitat;
        this.number = number;
        this.size = size;
    }

    intro() {
        console.log("The " + this.name + " is a " + this.species + " bird with a size of " + this.size + ", living in " + this.habitat + " with a population of " + this.number);
    }

    totalMass() {
        if (this.size === "small") {
            console.log("Total mass of " + this.name + " birds: " + 10 * this.number + " kg");
        } else if (this.size === "medium") {
            console.log("Total mass of " + this.name + " birds: " + 20 * this.number + " kg");
        } else if (this.size === "large") {
            console.log("Total mass of " + this.name + " birds: " + 30 * this.number + " kg");
        } else {
            console.log("Unidentifiable Bird");
        }
    }
}

class BirdProxy extends Bird {
    constructor(realBird) {
        super(realBird.name, realBird.species, realBird.size, realBird.habitat, realBird.number);
        this.realBird = realBird;
    }

    intro() {
        console.log("Proxy: Checking access before introducing the bird.");
        this.realBird.intro();
    }

    totalMass() {
        console.log("Proxy: Checking access before calculating total mass.");
        this.realBird.totalMass();
    }
}

const sparrow = new Bird("sparrow", "small", "small", "urban", 100);
const eagle = new Bird("eagle", "large", "medium", "mountain", 5);
const penguin = new Bird("penguin", "large", "large", "antarctic", 50);

const sparrowProxy = new BirdProxy(sparrow);
const eagleProxy = new BirdProxy(eagle);
const penguinProxy = new BirdProxy(penguin);

console.log("=============================== Output ====================================");
console.log("");
sparrowProxy.intro();
sparrowProxy.totalMass();
eagleProxy.intro();
eagleProxy.totalMass();
penguinProxy.intro();
penguinProxy.totalMass();