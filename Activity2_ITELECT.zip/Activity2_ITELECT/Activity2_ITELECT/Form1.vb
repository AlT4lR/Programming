﻿Public Class Form1
    'Prelim
    Dim PQ1, PQ2, PQ3, PAtt, PRec, PAct1, PAct2, PAct3, PExam As Integer
    'Midterm
    Dim MQ1, MQ2, MQ3, MAtt, MRec, MAct1, MAct2, MAct3, MExam As Integer
    'Finals
    Dim FQ1, FQ2, FQ3, FAtt, FRec, FAct1, FAct2, FAct3, FExam As Integer

    'Variables
    Dim PtotQ, PTotAtt, PTotRec, PTotAct, PTotExam As Double
    Dim MTotQ, MTotAtt, MTotRec, MTotAct, MTotExam As Double
    Dim FTotQ, FTotAtt, FTotRec, FTotAct, FTotExam As Double
    Dim Prelim, Midterm, Finals, Grade As Double
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        PQ1 = Val(TextBox1.Text)
        PQ2 = Val(TextBox2.Text)
        PQ3 = Val(TextBox3.Text)
        PAtt = Val(TextBox4.Text)
        PRec = Val(TextBox5.Text)
        PAct1 = Val(TextBox6.Text)
        PAct2 = Val(TextBox7.Text)
        PAct3 = Val(TextBox8.Text)
        PExam = Val(TextBox9.Text)


        PtotQ = ((PQ1 + PQ2 + PQ3) / 3) * 0.2
        PTotAtt = PAtt * 0.1
        PTotRec = PRec * 0.15
        PTotAct = ((PAct1 + PAct2 + PAct3) / 3) * 0.25
        PTotExam = PExam * 0.3


        Prelim = (PtotQ + PTotAtt + PTotRec + PTotAct + PTotExam) * 0.3

        TextBox10.Text = Prelim
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MQ1 = Val(TextBox20.Text)
        MQ2 = Val(TextBox19.Text)
        MQ3 = Val(TextBox18.Text)
        MAtt = Val(TextBox17.Text)
        MRec = Val(TextBox16.Text)
        MAct1 = Val(TextBox15.Text)
        MAct2 = Val(TextBox14.Text)
        MAct3 = Val(TextBox13.Text)
        MExam = Val(TextBox12.Text)


        MTotQ = ((MQ1 + MQ2 + MQ3) / 3) * 0.2
        MTotAtt = MAtt * 0.1
        MTotRec = MRec * 0.15
        MTotAct = ((MAct1 + MAct2 + MAct3) / 3) * 0.25
        MTotExam = MExam * 0.3


        Midterm = (MTotQ + MTotAtt + MTotRec + MTotAct + MTotExam) * 0.3


        TextBox11.Text = Midterm
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        FQ1 = Val(TextBox30.Text)
        FQ2 = Val(TextBox29.Text)
        FQ3 = Val(TextBox28.Text)
        FAtt = Val(TextBox27.Text)
        FRec = Val(TextBox26.Text)
        FAct1 = Val(TextBox25.Text)
        FAct2 = Val(TextBox24.Text)
        FAct3 = Val(TextBox23.Text)
        FExam = Val(TextBox22.Text)


        FTotQ = ((FQ1 + FQ2 + FQ3) / 3) * 0.2
        FTotAtt = FAtt * 0.1
        FTotRec = FRec * 0.15
        FTotAct = ((FAct1 + FAct2 + FAct3) / 3) * 0.25
        FTotExam = FExam * 0.3


        Finals = (FTotQ + FTotAtt + FTotRec + FTotAct + FTotExam) * 0.3


        TextBox21.Text = Finals
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Grade = Prelim + Midterm + Finals
        TextBox31.Text = Grade
    End Sub

End Class
