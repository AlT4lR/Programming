﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        TextBox3 = New TextBox()
        TextBox4 = New TextBox()
        TextBox5 = New TextBox()
        TextBox6 = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        TextBox7 = New TextBox()
        TextBox8 = New TextBox()
        TextBox9 = New TextBox()
        Button1 = New Button()
        TextBox10 = New TextBox()
        Label10 = New Label()
        Label11 = New Label()
        Label12 = New Label()
        TextBox11 = New TextBox()
        Button2 = New Button()
        TextBox12 = New TextBox()
        TextBox13 = New TextBox()
        TextBox14 = New TextBox()
        Label13 = New Label()
        Label14 = New Label()
        Label15 = New Label()
        Label16 = New Label()
        Label17 = New Label()
        Label18 = New Label()
        Label19 = New Label()
        Label20 = New Label()
        Label21 = New Label()
        TextBox15 = New TextBox()
        TextBox16 = New TextBox()
        TextBox17 = New TextBox()
        TextBox18 = New TextBox()
        TextBox19 = New TextBox()
        TextBox20 = New TextBox()
        Label22 = New Label()
        TextBox21 = New TextBox()
        Button3 = New Button()
        TextBox22 = New TextBox()
        TextBox23 = New TextBox()
        TextBox24 = New TextBox()
        Label23 = New Label()
        Label24 = New Label()
        Label25 = New Label()
        Label26 = New Label()
        Label27 = New Label()
        Label28 = New Label()
        Label29 = New Label()
        Label30 = New Label()
        Label31 = New Label()
        TextBox25 = New TextBox()
        TextBox26 = New TextBox()
        TextBox27 = New TextBox()
        TextBox28 = New TextBox()
        TextBox29 = New TextBox()
        TextBox30 = New TextBox()
        TextBox31 = New TextBox()
        Button4 = New Button()
        PictureBox1 = New PictureBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(373, 64)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(150, 31)
        TextBox1.TabIndex = 0
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(373, 120)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(150, 31)
        TextBox2.TabIndex = 1
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(373, 179)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(150, 31)
        TextBox3.TabIndex = 2
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(373, 348)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(150, 31)
        TextBox4.TabIndex = 5
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(373, 289)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(150, 31)
        TextBox5.TabIndex = 4
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(373, 233)
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(150, 31)
        TextBox6.TabIndex = 3
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label1.Location = New Point(241, 64)
        Label1.Name = "Label1"
        Label1.Size = New Size(59, 23)
        Label1.TabIndex = 6
        Label1.Text = "Quiz1"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label2.Location = New Point(241, 117)
        Label2.Name = "Label2"
        Label2.Size = New Size(59, 23)
        Label2.TabIndex = 7
        Label2.Text = "Quiz2"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label3.Location = New Point(241, 176)
        Label3.Name = "Label3"
        Label3.Size = New Size(59, 23)
        Label3.TabIndex = 8
        Label3.Text = "Quiz3"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label4.Location = New Point(241, 233)
        Label4.Name = "Label4"
        Label4.Size = New Size(111, 23)
        Label4.TabIndex = 9
        Label4.Text = "Attendance"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label5.Location = New Point(241, 292)
        Label5.Name = "Label5"
        Label5.Size = New Size(100, 23)
        Label5.TabIndex = 10
        Label5.Text = "Recitation"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label6.Location = New Point(241, 351)
        Label6.Name = "Label6"
        Label6.Size = New Size(86, 23)
        Label6.TabIndex = 11
        Label6.Text = "Activity1"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label7.Location = New Point(241, 403)
        Label7.Name = "Label7"
        Label7.Size = New Size(86, 23)
        Label7.TabIndex = 12
        Label7.Text = "Activity2"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label8.Location = New Point(241, 457)
        Label8.Name = "Label8"
        Label8.Size = New Size(86, 23)
        Label8.TabIndex = 13
        Label8.Text = "Activity3"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label9.Location = New Point(241, 505)
        Label9.Name = "Label9"
        Label9.Size = New Size(58, 23)
        Label9.TabIndex = 14
        Label9.Text = "Exam"
        ' 
        ' TextBox7
        ' 
        TextBox7.Location = New Point(373, 515)
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(150, 31)
        TextBox7.TabIndex = 17
        ' 
        ' TextBox8
        ' 
        TextBox8.Location = New Point(373, 456)
        TextBox8.Name = "TextBox8"
        TextBox8.Size = New Size(150, 31)
        TextBox8.TabIndex = 16
        ' 
        ' TextBox9
        ' 
        TextBox9.Location = New Point(373, 400)
        TextBox9.Name = "TextBox9"
        TextBox9.Size = New Size(150, 31)
        TextBox9.TabIndex = 15
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Button1.Location = New Point(214, 569)
        Button1.Name = "Button1"
        Button1.Size = New Size(129, 40)
        Button1.TabIndex = 18
        Button1.Text = "Prelim"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' TextBox10
        ' 
        TextBox10.Location = New Point(373, 581)
        TextBox10.Name = "TextBox10"
        TextBox10.Size = New Size(150, 31)
        TextBox10.TabIndex = 19
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Times New Roman", 9F, FontStyle.Bold Or FontStyle.Italic)
        Label10.Location = New Point(411, 18)
        Label10.Name = "Label10"
        Label10.Size = New Size(61, 21)
        Label10.TabIndex = 20
        Label10.Text = "Prelim"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Showcard Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(24, 18)
        Label11.Name = "Label11"
        Label11.Size = New Size(201, 23)
        Label11.TabIndex = 21
        Label11.Text = "Grade Calculator"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Times New Roman", 9F, FontStyle.Bold Or FontStyle.Italic)
        Label12.Location = New Point(736, 18)
        Label12.Name = "Label12"
        Label12.Size = New Size(75, 21)
        Label12.TabIndex = 42
        Label12.Text = "Midterm"
        ' 
        ' TextBox11
        ' 
        TextBox11.Location = New Point(698, 581)
        TextBox11.Name = "TextBox11"
        TextBox11.Size = New Size(150, 31)
        TextBox11.TabIndex = 41
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Button2.Location = New Point(551, 577)
        Button2.Name = "Button2"
        Button2.Size = New Size(129, 40)
        Button2.TabIndex = 40
        Button2.Text = "Midterm"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' TextBox12
        ' 
        TextBox12.Location = New Point(698, 515)
        TextBox12.Name = "TextBox12"
        TextBox12.Size = New Size(150, 31)
        TextBox12.TabIndex = 39
        ' 
        ' TextBox13
        ' 
        TextBox13.Location = New Point(698, 456)
        TextBox13.Name = "TextBox13"
        TextBox13.Size = New Size(150, 31)
        TextBox13.TabIndex = 38
        ' 
        ' TextBox14
        ' 
        TextBox14.Location = New Point(698, 400)
        TextBox14.Name = "TextBox14"
        TextBox14.Size = New Size(150, 31)
        TextBox14.TabIndex = 37
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label13.Location = New Point(578, 513)
        Label13.Name = "Label13"
        Label13.Size = New Size(58, 23)
        Label13.TabIndex = 36
        Label13.Text = "Exam"
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label14.Location = New Point(578, 465)
        Label14.Name = "Label14"
        Label14.Size = New Size(86, 23)
        Label14.TabIndex = 35
        Label14.Text = "Activity3"
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label15.Location = New Point(578, 411)
        Label15.Name = "Label15"
        Label15.Size = New Size(86, 23)
        Label15.TabIndex = 34
        Label15.Text = "Activity2"
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label16.Location = New Point(578, 359)
        Label16.Name = "Label16"
        Label16.Size = New Size(86, 23)
        Label16.TabIndex = 33
        Label16.Text = "Activity1"
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label17.Location = New Point(578, 300)
        Label17.Name = "Label17"
        Label17.Size = New Size(100, 23)
        Label17.TabIndex = 32
        Label17.Text = "Recitation"
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label18.Location = New Point(578, 241)
        Label18.Name = "Label18"
        Label18.Size = New Size(111, 23)
        Label18.TabIndex = 31
        Label18.Text = "Attendance"
        ' 
        ' Label19
        ' 
        Label19.AutoSize = True
        Label19.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label19.Location = New Point(578, 184)
        Label19.Name = "Label19"
        Label19.Size = New Size(59, 23)
        Label19.TabIndex = 30
        Label19.Text = "Quiz3"
        ' 
        ' Label20
        ' 
        Label20.AutoSize = True
        Label20.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label20.Location = New Point(578, 125)
        Label20.Name = "Label20"
        Label20.Size = New Size(59, 23)
        Label20.TabIndex = 29
        Label20.Text = "Quiz2"
        ' 
        ' Label21
        ' 
        Label21.AutoSize = True
        Label21.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label21.Location = New Point(578, 72)
        Label21.Name = "Label21"
        Label21.Size = New Size(59, 23)
        Label21.TabIndex = 28
        Label21.Text = "Quiz1"
        ' 
        ' TextBox15
        ' 
        TextBox15.Location = New Point(698, 348)
        TextBox15.Name = "TextBox15"
        TextBox15.Size = New Size(150, 31)
        TextBox15.TabIndex = 27
        ' 
        ' TextBox16
        ' 
        TextBox16.Location = New Point(698, 289)
        TextBox16.Name = "TextBox16"
        TextBox16.Size = New Size(150, 31)
        TextBox16.TabIndex = 26
        ' 
        ' TextBox17
        ' 
        TextBox17.Location = New Point(698, 233)
        TextBox17.Name = "TextBox17"
        TextBox17.Size = New Size(150, 31)
        TextBox17.TabIndex = 25
        ' 
        ' TextBox18
        ' 
        TextBox18.Location = New Point(698, 179)
        TextBox18.Name = "TextBox18"
        TextBox18.Size = New Size(150, 31)
        TextBox18.TabIndex = 24
        ' 
        ' TextBox19
        ' 
        TextBox19.Location = New Point(698, 120)
        TextBox19.Name = "TextBox19"
        TextBox19.Size = New Size(150, 31)
        TextBox19.TabIndex = 23
        ' 
        ' TextBox20
        ' 
        TextBox20.Location = New Point(698, 64)
        TextBox20.Name = "TextBox20"
        TextBox20.Size = New Size(150, 31)
        TextBox20.TabIndex = 22
        ' 
        ' Label22
        ' 
        Label22.AutoSize = True
        Label22.Font = New Font("Times New Roman", 9F, FontStyle.Bold Or FontStyle.Italic)
        Label22.Location = New Point(1057, 18)
        Label22.Name = "Label22"
        Label22.Size = New Size(58, 21)
        Label22.TabIndex = 63
        Label22.Text = "Finals"
        ' 
        ' TextBox21
        ' 
        TextBox21.Location = New Point(1019, 577)
        TextBox21.Name = "TextBox21"
        TextBox21.Size = New Size(150, 31)
        TextBox21.TabIndex = 62
        ' 
        ' Button3
        ' 
        Button3.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Button3.Location = New Point(865, 574)
        Button3.Name = "Button3"
        Button3.Size = New Size(129, 40)
        Button3.TabIndex = 61
        Button3.Text = "Finals"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' TextBox22
        ' 
        TextBox22.Location = New Point(1019, 515)
        TextBox22.Name = "TextBox22"
        TextBox22.Size = New Size(150, 31)
        TextBox22.TabIndex = 60
        ' 
        ' TextBox23
        ' 
        TextBox23.Location = New Point(1019, 456)
        TextBox23.Name = "TextBox23"
        TextBox23.Size = New Size(150, 31)
        TextBox23.TabIndex = 59
        ' 
        ' TextBox24
        ' 
        TextBox24.Location = New Point(1019, 400)
        TextBox24.Name = "TextBox24"
        TextBox24.Size = New Size(150, 31)
        TextBox24.TabIndex = 58
        ' 
        ' Label23
        ' 
        Label23.AutoSize = True
        Label23.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label23.Location = New Point(892, 510)
        Label23.Name = "Label23"
        Label23.Size = New Size(58, 23)
        Label23.TabIndex = 57
        Label23.Text = "Exam"
        ' 
        ' Label24
        ' 
        Label24.AutoSize = True
        Label24.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label24.Location = New Point(892, 462)
        Label24.Name = "Label24"
        Label24.Size = New Size(86, 23)
        Label24.TabIndex = 56
        Label24.Text = "Activity3"
        ' 
        ' Label25
        ' 
        Label25.AutoSize = True
        Label25.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label25.Location = New Point(892, 408)
        Label25.Name = "Label25"
        Label25.Size = New Size(86, 23)
        Label25.TabIndex = 55
        Label25.Text = "Activity2"
        ' 
        ' Label26
        ' 
        Label26.AutoSize = True
        Label26.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label26.Location = New Point(892, 356)
        Label26.Name = "Label26"
        Label26.Size = New Size(86, 23)
        Label26.TabIndex = 54
        Label26.Text = "Activity1"
        ' 
        ' Label27
        ' 
        Label27.AutoSize = True
        Label27.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label27.Location = New Point(892, 297)
        Label27.Name = "Label27"
        Label27.Size = New Size(100, 23)
        Label27.TabIndex = 53
        Label27.Text = "Recitation"
        ' 
        ' Label28
        ' 
        Label28.AutoSize = True
        Label28.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label28.Location = New Point(892, 238)
        Label28.Name = "Label28"
        Label28.Size = New Size(111, 23)
        Label28.TabIndex = 52
        Label28.Text = "Attendance"
        ' 
        ' Label29
        ' 
        Label29.AutoSize = True
        Label29.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label29.Location = New Point(892, 181)
        Label29.Name = "Label29"
        Label29.Size = New Size(59, 23)
        Label29.TabIndex = 51
        Label29.Text = "Quiz3"
        ' 
        ' Label30
        ' 
        Label30.AutoSize = True
        Label30.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label30.Location = New Point(892, 122)
        Label30.Name = "Label30"
        Label30.Size = New Size(59, 23)
        Label30.TabIndex = 50
        Label30.Text = "Quiz2"
        ' 
        ' Label31
        ' 
        Label31.AutoSize = True
        Label31.Font = New Font("Yu Gothic", 9F, FontStyle.Bold)
        Label31.Location = New Point(892, 69)
        Label31.Name = "Label31"
        Label31.Size = New Size(59, 23)
        Label31.TabIndex = 49
        Label31.Text = "Quiz1"
        ' 
        ' TextBox25
        ' 
        TextBox25.Location = New Point(1019, 348)
        TextBox25.Name = "TextBox25"
        TextBox25.Size = New Size(150, 31)
        TextBox25.TabIndex = 48
        ' 
        ' TextBox26
        ' 
        TextBox26.Location = New Point(1019, 289)
        TextBox26.Name = "TextBox26"
        TextBox26.Size = New Size(150, 31)
        TextBox26.TabIndex = 47
        ' 
        ' TextBox27
        ' 
        TextBox27.Location = New Point(1019, 233)
        TextBox27.Name = "TextBox27"
        TextBox27.Size = New Size(150, 31)
        TextBox27.TabIndex = 46
        ' 
        ' TextBox28
        ' 
        TextBox28.Location = New Point(1019, 179)
        TextBox28.Name = "TextBox28"
        TextBox28.Size = New Size(150, 31)
        TextBox28.TabIndex = 45
        ' 
        ' TextBox29
        ' 
        TextBox29.Location = New Point(1019, 120)
        TextBox29.Name = "TextBox29"
        TextBox29.Size = New Size(150, 31)
        TextBox29.TabIndex = 44
        ' 
        ' TextBox30
        ' 
        TextBox30.Location = New Point(1019, 64)
        TextBox30.Name = "TextBox30"
        TextBox30.Size = New Size(150, 31)
        TextBox30.TabIndex = 43
        ' 
        ' TextBox31
        ' 
        TextBox31.Location = New Point(24, 437)
        TextBox31.Name = "TextBox31"
        TextBox31.Size = New Size(150, 31)
        TextBox31.TabIndex = 64
        ' 
        ' Button4
        ' 
        Button4.Font = New Font("Yu Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button4.Location = New Point(37, 391)
        Button4.Name = "Button4"
        Button4.Size = New Size(129, 40)
        Button4.TabIndex = 65
        Button4.Text = "Final Grade"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources._405933400_1789202008175202_7858345175958427478_n
        PictureBox1.Location = New Point(48, 64)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(104, 106)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 66
        PictureBox1.TabStop = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1253, 643)
        Controls.Add(PictureBox1)
        Controls.Add(Button4)
        Controls.Add(TextBox31)
        Controls.Add(Label22)
        Controls.Add(TextBox21)
        Controls.Add(Button3)
        Controls.Add(TextBox22)
        Controls.Add(TextBox23)
        Controls.Add(TextBox24)
        Controls.Add(Label23)
        Controls.Add(Label24)
        Controls.Add(Label25)
        Controls.Add(Label26)
        Controls.Add(Label27)
        Controls.Add(Label28)
        Controls.Add(Label29)
        Controls.Add(Label30)
        Controls.Add(Label31)
        Controls.Add(TextBox25)
        Controls.Add(TextBox26)
        Controls.Add(TextBox27)
        Controls.Add(TextBox28)
        Controls.Add(TextBox29)
        Controls.Add(TextBox30)
        Controls.Add(Label12)
        Controls.Add(TextBox11)
        Controls.Add(Button2)
        Controls.Add(TextBox12)
        Controls.Add(TextBox13)
        Controls.Add(TextBox14)
        Controls.Add(Label13)
        Controls.Add(Label14)
        Controls.Add(Label15)
        Controls.Add(Label16)
        Controls.Add(Label17)
        Controls.Add(Label18)
        Controls.Add(Label19)
        Controls.Add(Label20)
        Controls.Add(Label21)
        Controls.Add(TextBox15)
        Controls.Add(TextBox16)
        Controls.Add(TextBox17)
        Controls.Add(TextBox18)
        Controls.Add(TextBox19)
        Controls.Add(TextBox20)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(TextBox10)
        Controls.Add(Button1)
        Controls.Add(TextBox7)
        Controls.Add(TextBox8)
        Controls.Add(TextBox9)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(TextBox4)
        Controls.Add(TextBox5)
        Controls.Add(TextBox6)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(TextBox1)
        Name = "Form1"
        Text = "Home"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents TextBox19 As TextBox
    Friend WithEvents TextBox20 As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents TextBox21 As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents TextBox22 As TextBox
    Friend WithEvents TextBox23 As TextBox
    Friend WithEvents TextBox24 As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents TextBox25 As TextBox
    Friend WithEvents TextBox26 As TextBox
    Friend WithEvents TextBox27 As TextBox
    Friend WithEvents TextBox28 As TextBox
    Friend WithEvents TextBox29 As TextBox
    Friend WithEvents TextBox30 As TextBox
    Friend WithEvents TextBox31 As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents PictureBox1 As PictureBox

End Class
