﻿Imports System.Runtime.InteropServices.Marshalling
Imports System.Text.RegularExpressions
Imports System.Threading

Public Class Form1
    Dim PQ1, PQ2, PQ3, PATT, PREC, PACT1, PACT2, PACT3, PEXAM, Prelim As Integer
    Dim PTOTQ, PTOTATT, PTOTREC, PTOTACT, PTOTEX As Integer
    Dim MQ1, MQ2, MQ3, MATT, MREC, MACT1, MACT2, MACT3, MEXAM, Midterm As Integer
    Dim MTOTQ, MTOTATT, MTOTREC, MTOTACT, MTOTEX As Integer
    Dim FQ1, FQ2, FQ3, FATT, FREC, FACT1, FACT2, FACT3, FEXAM, Finals As Integer
    Dim FTOTQ, FTOTATT, FTOTREC, FTOTACT, FTOTEX, Grades As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Prelim


        PQ1 = Val(TextBox1.Text)
        PQ2 = Val(TextBox2.Text)
        PQ3 = Val(TextBox3.Text)
        PATT = Val(TextBox6.Text)
        PREC = Val(TextBox5.Text)
        PACT1 = Val(TextBox4.Text)
        PACT2 = Val(TextBox9.Text)
        PACT3 = Val(TextBox8.Text)
        PEXAM = Val(TextBox7.Text)

        PTOTQ = (PQ1 + PQ2 + PQ3) / 3 * 0.2
        PTOTATT = PATT * 0.1
        PREC = PREC * 0.15
        PTOTACT = (PACT1 + PACT2 + PACT3) / 3 * 0.25
        PTOTEX = PEXAM * 0.3

        Prelim = PTOTQ + PTOTATT + PREC + PTOTACT + PTOTEX
        TextBox10.Text = Prelim
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        'Midterm


        MQ1 = Val(TextBox20.Text)
        MQ2 = Val(TextBox19.Text)
        MQ3 = Val(TextBox18.Text)
        MATT = Val(TextBox17.Text)
        MREC = Val(TextBox16.Text)
        MACT1 = Val(TextBox15.Text)
        MACT2 = Val(TextBox14.Text)
        MACT3 = Val(TextBox13.Text)
        MEXAM = Val(TextBox12.Text)


        MTOTQ = ((MQ1 + MQ2 + MQ3) / 3) * 0.2
        MTOTATT = MATT * 0.1
        MTOTREC = MREC * 0.15
        MTOTACT = ((MACT1 + MACT2 + MACT3) / 3) * 0.25
        MTOTEX = MEXAM * 0.3


        Midterm = MTOTQ + MTOTATT + MTOTREC + MTOTACT + MTOTEX

        TextBox11.Text = Midterm
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'Finals


        FQ1 = Val(TextBox30.Text)
        FQ2 = Val(TextBox29.Text)
        FQ3 = Val(TextBox28.Text)
        FATT = Val(TextBox27.Text)
        FREC = Val(TextBox26.Text)
        FACT1 = Val(TextBox25.Text)
        FACT2 = Val(TextBox24.Text)
        FACT3 = Val(TextBox23.Text)
        FEXAM = Val(TextBox22.Text)

        FTOTQ = ((FQ1 + FQ2 + FQ3) / 3) * 0.2
        FTOTATT = FATT * 0.1
        FTOTREC = FREC * 0.15
        FTOTACT = ((FACT1 + FACT2 + FACT3) / 3) * 0.25
        FTOTEX = FEXAM * 0.3

        Finals = FTOTQ + FTOTATT + FTOTREC + FTOTACT + FTOTEX

        TextBox21.Text = Finals
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Grades = Prelim + Midterm + Finals

        TextBox31.Text = Grades
    End Sub

    Private Sub TextBox31_TextChanged(sender As Object, e As EventArgs) Handles TextBox31.TextChanged

    End Sub
End Class
