﻿Imports System.Security.Cryptography

Public Class Form1
    Dim user, pass As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        user = TextBox1.Text
        pass = TextBox2.Text

        If user = "Adrian Vine" And pass = "Cruz" Then
            MessageBox.Show("Logged in Successfully")

        ElseIf user = TextBox1.Text And pass = "" Then
            MessageBox.Show("Please Enter your Password")

        ElseIf user = "" And pass = Textbox2.Text Then
            MessageBox.Show("Please Enter Your Username!")

        ElseIf user = TextBox1.Text And pass = TextBox2.Text Then
            MessageBox.Show("Please Enter your Username and Password")

        Else
            MessageBox.Show("Wrong Username and Password")


        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        TextBox1.Clear()
        TextBox2.Clear()

    End Sub
End Class
