﻿Imports System.Security.Cryptography

Public Class Form1
    Dim user, pass As String
    Dim registeredUser As String = "" ' Variable to store registered username
    Dim registeredPass As String = "" ' Variable to store registered password

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        user = TextBox1.Text
        pass = TextBox2.Text

        If user = registeredUser And pass = registeredPass Then
            MessageBox.Show("Logged in Successfully")
        ElseIf user = registeredUser And pass = "" Then
            MessageBox.Show("Please Enter your Password")
        ElseIf user = "" And pass = registeredPass Then
            MessageBox.Show("Please Enter Your Username!")
        ElseIf user = registeredUser And pass = "" Then
            MessageBox.Show("Please Enter your Password")
        ElseIf user = "" And pass = "" Then
            MessageBox.Show("Please Enter your Username and Password")
        Else
            MessageBox.Show("Wrong Username and Password")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim recoveredPassword As String = registeredPass ' For demonstration purposes, assuming the password is stored in registeredPass
        MessageBox.Show($"Your password is: {recoveredPassword}")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        ' Registration button
        registeredUser = TextBox1.Text
        registeredPass = TextBox2.Text

        If registeredUser = "" Or registeredPass = "" Then
            MessageBox.Show("Please enter both username and password for registration.")
        Else
            MessageBox.Show("Registration successful!")
        End If
    End Sub
End Class

