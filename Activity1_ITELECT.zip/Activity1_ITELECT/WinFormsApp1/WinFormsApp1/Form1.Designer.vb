﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        Button5 = New Button()
        Button6 = New Button()
        Button7 = New Button()
        Button8 = New Button()
        Button9 = New Button()
        Button10 = New Button()
        Button11 = New Button()
        Label1 = New Label()
        SuspendLayout()
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(69, 160)
        Button1.Name = "Button1"
        Button1.Size = New Size(125, 38)
        Button1.TabIndex = 1
        Button1.Text = "Act1"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(69, 217)
        Button2.Name = "Button2"
        Button2.Size = New Size(125, 38)
        Button2.TabIndex = 2
        Button2.Text = "Act2"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(69, 271)
        Button3.Name = "Button3"
        Button3.Size = New Size(125, 38)
        Button3.TabIndex = 3
        Button3.Text = "Act3"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Location = New Point(69, 327)
        Button4.Name = "Button4"
        Button4.Size = New Size(125, 38)
        Button4.TabIndex = 4
        Button4.Text = "Act4"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Location = New Point(312, 160)
        Button5.Name = "Button5"
        Button5.Size = New Size(125, 38)
        Button5.TabIndex = 5
        Button5.Text = "Act5"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Location = New Point(312, 217)
        Button6.Name = "Button6"
        Button6.Size = New Size(125, 38)
        Button6.TabIndex = 6
        Button6.Text = "Act6"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Button7
        ' 
        Button7.Location = New Point(312, 271)
        Button7.Name = "Button7"
        Button7.Size = New Size(125, 38)
        Button7.TabIndex = 7
        Button7.Text = "Act7"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Button8
        ' 
        Button8.Location = New Point(312, 327)
        Button8.Name = "Button8"
        Button8.Size = New Size(125, 38)
        Button8.TabIndex = 8
        Button8.Text = "Act8"
        Button8.UseVisualStyleBackColor = True
        ' 
        ' Button9
        ' 
        Button9.Location = New Point(503, 160)
        Button9.Name = "Button9"
        Button9.Size = New Size(125, 38)
        Button9.TabIndex = 9
        Button9.Text = "Act9"
        Button9.UseVisualStyleBackColor = True
        ' 
        ' Button10
        ' 
        Button10.Location = New Point(503, 217)
        Button10.Name = "Button10"
        Button10.Size = New Size(125, 38)
        Button10.TabIndex = 10
        Button10.Text = "Act10"
        Button10.UseVisualStyleBackColor = True
        ' 
        ' Button11
        ' 
        Button11.Location = New Point(503, 271)
        Button11.Name = "Button11"
        Button11.Size = New Size(125, 38)
        Button11.TabIndex = 11
        Button11.Text = "Act11"
        Button11.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(290, 72)
        Label1.Name = "Label1"
        Label1.Size = New Size(182, 23)
        Label1.TabIndex = 12
        Label1.Text = "Activity 1 IT_ELECT"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Label1)
        Controls.Add(Button11)
        Controls.Add(Button10)
        Controls.Add(Button9)
        Controls.Add(Button8)
        Controls.Add(Button7)
        Controls.Add(Button6)
        Controls.Add(Button5)
        Controls.Add(Button4)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Name = "Form1"
        Text = "Home"
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Label1 As Label

End Class
